const Customer = require('../models/customer');

exports.getCustomers = async (req, res) => {
  const [rows] = await Customer.getAllCustomers();
  res.json(rows);
};

exports.addCustomer = async (req, res) => {
  await Customer.createCustomer(req.body);
  res.status(201).json({ message: 'Customer added' });
};
