const Supplier = require('../models/supplier');

exports.getSuppliers = async (req, res) => {
  const [rows] = await Supplier.getAllSuppliers();
  res.json(rows);
};

exports.addSupplier = async (req, res) => {
  await Supplier.createSupplier(req.body);
  res.status(201).json({ message: 'Supplier added' });
};

exports.deleteSupplier = async (req, res) => {
  await Supplier.deleteSupplier(req.params.id);
  res.json({ message: 'Supplier deleted' });
};