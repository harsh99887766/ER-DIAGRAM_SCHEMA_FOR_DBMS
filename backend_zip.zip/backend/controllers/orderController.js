const Order = require('../models/order');

exports.createOrder = async (req, res) => {
  await Order.createOrder(req.body);
  res.status(201).json({ message: 'Order created' });
};

exports.searchOrderByCustomer = async (req, res) => {
  const [rows] = await Order.getOrderByCustomer(req.params.query);
  res.json(rows);
};