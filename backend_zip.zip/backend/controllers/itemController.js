const Item = require('../models/item');

exports.getItems = async (req, res) => {
  const [rows] = await Item.getAllItems();
  res.json(rows);
};

exports.addItem = async (req, res) => {
  await Item.createItem(req.body);
  res.status(201).json({ message: 'Item added' });
};

exports.deleteItem = async (req, res) => {
  await Item.deleteItem(req.params.id);
  res.json({ message: 'Item deleted' });
};