const express = require('express');
const router = express.Router();
const itemController = require('../controllers/itemController');
const db = require('../config/db');
router.get('/', async (req, res) => {
    try {
        const [items] = await db.query('SELECT * FROM Items');
        res.json(items);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch items' });
    }
});
router.post('/', itemController.addItem);
router.delete('/:id', itemController.deleteItem);

module.exports = router;