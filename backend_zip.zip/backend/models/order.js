const db = require('../config/db');

exports.createOrder = (data) => db.query('INSERT INTO Orders SET ?', [data]);
exports.getOrderByCustomer = (phoneOrNameOrId) =>
  db.query(`SELECT * FROM Orders o JOIN Customers c ON o.customer_id = c.customer_id
            WHERE c.phone = ? OR c.name = ? OR c.customer_id = ?`,
            [phoneOrNameOrId, phoneOrNameOrId, phoneOrNameOrId]);
