const db = require('../config/db');

exports.getAllCategories = () => db.query('SELECT * FROM Categories');
exports.createCategory = (data) => db.query('INSERT INTO Categories SET ?', [data]);
exports.deleteCategory = (id) => db.query('DELETE FROM Categories WHERE category_id = ?', [id]);
