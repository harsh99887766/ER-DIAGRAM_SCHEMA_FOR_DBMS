const db = require('../config/db');

exports.getAllCustomers = () => db.query('SELECT * FROM Customers');
exports.getCustomerById = (id) => db.query('SELECT * FROM Customers WHERE customer_id = ?', [id]);
exports.createCustomer = (data) => db.query('INSERT INTO Customers SET ?', [data]);
