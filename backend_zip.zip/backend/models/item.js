const db = require('../config/db');

exports.getAllItems = () => db.query('SELECT * FROM Items');
exports.createItem = (data) => db.query('INSERT INTO Items SET ?', [data]);
exports.deleteItem = (id) => db.query('DELETE FROM Items WHERE item_id = ?', [id]);
