const db = require('../config/db');

exports.getAllSuppliers = () => db.query('SELECT * FROM Suppliers');
exports.createSupplier = (data) => db.query('INSERT INTO Suppliers SET ?', [data]);
exports.deleteSupplier = (id) => db.query('DELETE FROM Suppliers WHERE supplier_id = ?', [id]);
